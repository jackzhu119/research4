research4 最终论文与投稿包 | 2026-11-15

01_Submit：英文正文、标题页、投稿信、英文补充材料、声明、数据附件与最终图片。
02_Review：完整正文中英对照及中文使用说明，供作者审阅。
03_Evidence：完整冻结证据、源稿、翻译、构建代码和哈希核验，供追溯。

请先阅读02_Review/02_投稿文件说明.docx。图有600 dpi PNG及矢量PDF，每图择一上传。
正文按实际数据标注和已确认条件完成，旧实验参数补齐表已经撤下。冻结证据中的历史缺失字段保留原貌。
全体作者及Yin Shen通讯标记、ORCID、共同单位与责任声明已写入文件；数据来源已说明，亦用于导师其他指导研究。
文件准备完成，未代为向期刊提交。账号持有人在系统授权ORCID、预览生成PDF后执行提交。

仓库：https://github.com/jackzhu119/research4
当前修订：https://github.com/jackzhu119/research4/pull/19
原始18份工作簿通过仓库data/active_workbooks.json定位，不在本包重复复制。
03_Evidence/authoring_sources脚本原位在仓库执行；独立压缩包保留源代码供审阅。
