Supplementary Data S1

Manuscript: Terahertz fingerprints and machine learning for complementary discrimination of medicinal materials
Authors: Ziyuan Zhu, Jiayi Ren, Shuyu Zhou, Mengting Zhu and Yin Shen
Corresponding author: Yin Shen; shenyin285819016@126.com
ORCID (Ziyuan Zhu, first author): https://orcid.org/0009-0005-1153-4926
ORCID (Yin Shen, corresponding author): https://orcid.org/0000-0002-3221-7875

The measured dataset was supplied by the corresponding author and is a shared resource used in other supervised research. This archive supports the analyses reported in the present manuscript.

corrected_tables: all included corrected positive and negative settings, task definitions, model settings, paired effects and B1-B5 results.
specimen_inputs: recorded labels, frozen roles, workbook registry and nominal header thickness annotations.
protocols and mechanism_summaries: the locked analysis definitions and mechanism endpoints.
derived_checks and verified_v4_sources: archived predictions/features and the feature-budget reanalysis.
kind_lowo: the fixed-pipeline workbook-held-out material protocol, complete grouped partitions and out-of-workbook predictions.
accepted_molecular: the two qualified protocatechuic-acid mode and infrared calculations and numerical checks.

The 18 original spectral workbooks are available from the repository data registry and are not duplicated in this archive. Four workbook views describe the same specimens. Task counts and repeated predictions do not increase physical specimen counts. Only the material-discrimination LOWO analysis adds classifier fits (10 binary and18 four-material folds); all source-group, representation and mechanism results remain archived, and no new quantum calculations were run.

Canonical repository: https://github.com/jackzhu119/research4
SOURCE_MANIFEST.json identifies copied data by SHA-256 and records the source paths.
