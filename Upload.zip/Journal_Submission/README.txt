APPLIED SPECTROSCOPY JOURNAL SUBMISSION FILES

Extract this archive and upload its individual files in the journal system.
Do not upload this ZIP as the main manuscript.

01_Manuscript.docx: Manuscript or Main document.
02_Title_Page.docx: Title page.
03_Cover_Letter.docx: Cover letter.
04_Supplementary_Information.docx: Supplemental material.
Supplementary_Tables.xlsx and Supplementary_B1.xlsx through
Supplementary_B5.xlsx: Supplemental data; each workbook is below 10 MiB.
Figures/Figure_1.eps through Figures/Figure_5.eps: Five main figures.
Supplementary_Figure/Figure_S1.eps: Supplementary figure S1.
Optional/Declarations.docx: Use only if the system asks for a separate
declaration file. The relevant declarations are already in the manuscript.

The EPS files are the production figure versions. Do not register additional
copies of the same figure under different file formats. Use the journal's
actual file-type options and check its generated PDF before final submission.

The package includes named ORCIDs for first author Ziyuan Zhu and corresponding
author Yin Shen. The submitting author must authorize their own ORCID in their
journal account. No journal submission has been performed by this package.
