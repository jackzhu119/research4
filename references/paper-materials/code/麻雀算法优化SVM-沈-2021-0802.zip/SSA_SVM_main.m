clear all;
clc;
close all;
% ��������б�
class_list = {'A', 'B', 'C', 'D', 'E', 'G', 'H', 'I', 'J', 'K', 'L', 'S'};
% ���ú�����ȡ���׾���,�������ƺ����б�
[dataMatrix, sample_group, wavelength, sample_names] = data_extract(class_list);
% ��ȡ������Ŀ
uqL = unique(sample_group);
nLabels = length(uqL);       % �����Ŀ
n = length(sample_group);    % ��������Ŀ
% 
sample_label = [];
for i = 1:length(sample_group)
    sample_label(i,1) = find(strcmpi(uqL, sample_group{i}));
end
% ���ú����������ݽ��зָ�, ��K = 5��������֤���зָ�
K = 5;
[KfoldIndex] = dataset_split(sample_group, K);
% �����ݽ��й�һ��
dataMatrix2 = max_min_scale(dataMatrix);

% �趨����ȸ�㷨����
SearchAgents_no = 10;  % Number of search agents
Max_iteration   = 100;  % Maximum numbef of iterations
lb  = [-5, -5];        % ��Сֵ��Χ
ub  = [5, 5];          % ���ֵ��Χ
dim = 2;               % ���峤��
fobj = @(x) f(x,dataMatrix2,sample_label, KfoldIndex, uqL, sample_names);   % ������Ӧ�Ⱥ���
[fMin, bestX, SSA_curve] = SSA(SearchAgents_no, Max_iteration, lb, ub, dim, fobj, dataMatrix2,sample_label, KfoldIndex, uqL, sample_names);  

%Draw objective space
figure;
plot(SSA_curve,'r-+')  
title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');
%axis tight
grid on
box on
legend('SSA')
print(gcf, '-dpng', 'SSA_curve.png', '-r300');


display(['The best solution obtained by SSA is : ', num2str(bestX)]);
display(['The best optimal value of the objective funciton found by SSA is : ', num2str(fMin)]);

% ������Ѳ����������
log2C = bestX(1);
log2G  = bestX(2);
[pred_Result, real_label, test_names, Kindex] =  cross_validation(KfoldIndex, dataMatrix2, sample_label, sample_names, uqL, log2C, log2G);
% ����������Ԥ�����ͷ���ĸ��ʾ���
save_prediction_details(pred_Result, real_label, test_names, Kindex);  % ���ú�������Ԥ��ϸ��

num = 0;
for i = 1:length(pred_Result)
    if strcmpi(pred_Result{i}, real_label{i})
        num = num + 1;
    end
end
ypred = num/(length(real_label)) * 100;
fprintf('%d ��������׼ȷ��%f\n', K, ypred);
% ���Ʒ����������
pred_Mat = zeros(n,nLabels);
test_Mat = zeros(n,nLabels);
for i = 1:length(pred_Result)
    I1 = find(strcmpi(uqL, pred_Result{i}));
    I2 = find(strcmpi(uqL, real_label{i}));
    pred_Mat(i,I1) = 1;
    test_Mat(i,I2) = 1;
end
% ���ƻ�������
figure;
plotconfusion(test_Mat', pred_Mat');
h = gca;
h.XTickLabel = [uqL; {''}];
h.YTickLabel = [uqL; {''}];
set(gcf, 'Position', get(0, 'ScreenSize'));
print(gcf, '-dpng', 'SVM_Confusion.png', '-r300');
% ��ȡ�����ľ���
ConfMat = confusionmat(real_label, pred_Result);
% ���ú���������
save_confMat_tofile(ConfMat, uqL);

save Result;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ���庯�������潻����֤��Ԥ��ϸ�ڽ��
function save_prediction_details(pred_Result, real_label, test_names, Kindex)
    fide0 = fopen('SVM_Kfold_CrossValidation.txt', 'w');
    fprintf(fide0, '%s\t%s\t%s\t%s\n', 'KfoldIndex', '��������', '����ǩ', 'Ԥ�����');
    for i = 1:length(pred_Result)
        splitstr = [{Kindex(i)}, test_names(i), real_label(i), pred_Result(i)];
        for j = 1:length(splitstr)
            splitstr{j} = num2str(splitstr{j});
        end
        fprintf(fide0, '%s\n', strjoin(splitstr, '\t'));
    end
    fclose(fide0);
end

% ���庯�����������������
function save_confMat_tofile(ConfMat, uq)
    fide0 = fopen('SVM_confusionMatrix.txt', 'w');
    fprintf(fide0, '%s\t%s\n', '', strjoin(uq', '\t'));
    for i = 1:size(ConfMat,1)
        splitstr = [uq(i), num2cell(ConfMat(i,:))];
        for j = 1:length(splitstr)
            splitstr{j} = num2str(splitstr{j});
        end
       fprintf(fide0, '%s\n', strjoin(splitstr, '\t'));
    end
    fclose(fide0);
end

% ������ȸ�����㷨
function [fMin , bestX,Convergence_curve ] = SSA(pop, M, c, d, dim, fobj, dataMatrix2,sample_label, KfoldIndex, uqL, sample_names)
    P_percent = 0.2;    % The population size of producers accounts for "P_percent" percent of the total population size       
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    pNum = round( pop *  P_percent ); % The population size of the producers   
    lb = c.*ones( 1,dim );            % Lower limit/bounds/     a vector
    ub = d.*ones( 1,dim );            % Upper limit/bounds/     a vector
    %Initialization
    for i = 1:pop
        x(i,:) = lb + (ub - lb) .* rand(1, dim);  
        fit(i) = fobj(x(i,:)) ;                       
    end
    pFit = fit;                      
    pX   = x;                        % The individual's best position corresponding to the pFit
    [fMin, bestI] = min(fit);        % fMin denotes the global optimum fitness value
    bestX = x(bestI,:);              % bestX denotes the global optimum position corresponding to fMin
    % Start updating the solutions.
    for t = 1:M
        [ans, sortIndex] = sort(pFit); % Sort.
        [fmax, B] = max(pFit);
        worse = x(B,:);
        r2 = rand(1);
        if (r2 < 0.8) 
            for i = 1:pNum    % Equation (3)
                r1 = rand(1);
                x(sortIndex(i),:) = pX(sortIndex(i),:)*exp(-(i)/(r1*M));
                x( sortIndex(i),:) = Bounds(x(sortIndex(i),:),lb,ub);
                fit( sortIndex(i)) = fobj(x(sortIndex(i),:));   
            end
        else
            for i = 1 : pNum
                x( sortIndex(i),:)   = pX(sortIndex(i),:) + randn(1)*ones(1,dim);
                x( sortIndex( i ),:) = Bounds( x(sortIndex(i),:),lb,ub);
                fit( sortIndex( i )) = fobj( x(sortIndex(i),:));
            end
        end
        [fMMin, bestII] = min( fit );      
        bestXX = x(bestII,:);            
        for i = (pNum + 1):pop    % Equation (4)
            A = floor(rand(1,dim)*2)*2 - 1;
            if( i > (pop/2))
                x(sortIndex(i ),:)   = randn(1)*exp((worse - pX( sortIndex( i ),:))/(i)^2);
            else
                x( sortIndex( i ),:) = bestXX + (abs((pX( sortIndex( i ), :) - bestXX)))*(A'*(A*A')^(-1))*ones(1,dim);  
            end  
            x(sortIndex(i),:) = Bounds(x(sortIndex(i), :),lb,ub);
            fit(sortIndex(i)) = fobj( x( sortIndex(i), :));
        end
        c = randperm(numel(sortIndex));
        b = sortIndex(c(1:5));
        for j =  1:length(b)      % Equation (5)
            if (pFit(sortIndex(b(j)))> (fMin))
                x(sortIndex(b(j)),:) = bestX + (randn(1,dim)).*(abs((pX(sortIndex(b(j)),:) - bestX)));
            else
                x( sortIndex(b(j)),:) = pX(sortIndex(b(j)),:) + (2*rand(1) - 1)*(abs(pX(sortIndex(b(j)), :) - worse))/(pFit(sortIndex(b(j))) - fmax + 1e-50);
            end
            x(sortIndex(b(j)),:) = Bounds(x(sortIndex(b(j)),:), lb, ub);       
            fit( sortIndex( b(j) ) ) = fobj( x( sortIndex( b(j) ), : ) );
        end
        for i = 1:pop 
            if (fit(i) < pFit(i))
                pFit(i) = fit(i);
                pX(i,:) = x(i,:);
            end
            if (pFit(i) < fMin)
                fMin = pFit(i);
                bestX = pX(i,:);
            end
        end
        Convergence_curve(t) = fMin;
        fprintf('%d\n', t);
    end
end

% Application of simple limits/bounds
function s = Bounds(s, Lb, Ub)
    [m,n] = size(s);
    for i = 1:m
        temp = s(i,:);
        for j = 1:n
            % Apply the lower bound vector
            if temp(j) < Lb(j)
                temp(j) = Lb(j);
            end
            % Apply the upper bound vector 
            if temp(j) > Ub(j)
                temp(j) = Ub(j);
            end
        end
        % Update this new move 
        s(i,:) = temp;
    end
end

% ���庯�������ݽ��б�׼��, ���õ���max-min�����С��׼��, ��ÿ������������ϵ����һ����
% 0 ~ 1 ֮��
function dataMatrix = max_min_scale(dataMatrix)
    [m, n] = size(dataMatrix);
    for i = 1:m
        tmpD = dataMatrix(i,:);
        minD = min(tmpD);
        maxD = max(tmpD);
        tmpD = (tmpD - minD)/(maxD - minD);
        dataMatrix(i,:) = tmpD;
    end
end

% ���庯�����ָ�����
function [KfoldIndex] = dataset_split(sample_group, K)
    uq1 = unique(sample_group);
    KfoldIndex = zeros(length(sample_group),1);
    for i = 1:length(uq1)
        I1 = find(strcmpi(sample_group, uq1(i)));
        rand('seed',1)
        Indices = crossvalind('Kfold', length(I1), K);
        KfoldIndex(I1) = Indices;
    end
end

% ���庯����ȡ����
function [dataMatrix,sample_group, wavelength, sample_names] = data_extract(class_list)
    dataMatrix   = [];
    sample_group = {};
    wavelength   = [];
    sample_names = {};
    for i = 1:length(class_list)
        [X1, Y1, Z1] = xlsread(['����ϵ������/', class_list{i}, '����ϵ��.xlsx']);
        % ��ȡ����
        rowNum = size(Z1,1);
        for j = 1:size(Z1,1)
            if ~ischar(Z1{j,1})
                if isnan(Z1{j,1})
                    rowNum = j - 1;
                    break;
                end
            end
        end
        % ��ȡ����
        colNum = size(Z1,2);
        for j = 1:size(Z1,2)
            if ~ischar(Z1{1,j})
                if isnan(Z1{1,j})
                    colNum = j - 1;
                    break;
                end
            end
        end
        wavelength = cell2mat(Z1(1,2:colNum-1));
        sample_names = [sample_names; Z1(2:rowNum,1)];
        sample_group = [sample_group; repmat(class_list(i), rowNum - 1, 1)];
        dataMatrix   = [dataMatrix; cell2mat(Z1(2:rowNum, 2:colNum - 1))];
    end
end

% ������Ӧ�Ⱥ���f
function y = f(x,dataMatrix2,sample_label, KfoldIndex, uqL, sample_names)
    [m,n] = size(x);
    y = [];
    for i = 1:m
        log2C = x(i,1);
        log2G  = x(i,2);
        [pred_Result, real_label, test_names, Kindex] =  cross_validation(KfoldIndex, dataMatrix2, sample_label, sample_names, uqL, log2C, log2G);
        y(i) = sum(~strcmpi(pred_Result, real_label))/length(real_label);
    end
end
% ����һ���������н�����֤
function [pred_Result2, real_label2, test_names, Kindex] =  cross_validation(KfoldIndex, dataMatrix2, sample_label, sample_names, uqL, log2C, log2G)
    pred_Result  = [];
    real_label   = [];
    pred_Result2 = {};
    real_label2  = {};
    test_names   = {};
    Kindex = [];
    for i = 1:max(KfoldIndex)
        I1 = find(KfoldIndex == i);
        I2 = find(KfoldIndex ~= i);
        x_train = dataMatrix2(I2,:);
        y_train = sample_label(I2);
        x_test  = dataMatrix2(I1,:);
        y_test  = sample_label(I1);
        cmd = [' -q -c ',num2str(2^log2C),' -g ',num2str(2^log2G)]; % ����ѵ������
        model = svmtrain(y_train, x_train, cmd);   % ���ú���ѵ��svmtrainģ��
        Ytest = svmpredict(y_test, x_test, model,  ' -q '); % ���ú����Խ������Ԥ��ģ��
        pred_Result = [pred_Result; Ytest];
        real_label  = [real_label;  y_test];
        test_names = [test_names; sample_names(I1)];
        Kindex = [Kindex; KfoldIndex(I1)];
    end
    for i = 1:length(pred_Result)
        pred_Result2{i} = uqL{pred_Result(i)};
    end
    for i = 1:length(real_label)
        real_label2{i} = uqL{real_label(i)};
    end
end